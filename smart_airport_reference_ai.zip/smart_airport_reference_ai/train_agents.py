"""Fit and evaluate Agent A, then synthesize a simulation policy with Agent B."""

import argparse
import csv
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

import joblib
import numpy as np
import sklearn
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.metrics import f1_score, mean_absolute_error, r2_score, roc_auc_score
from sklearn.model_selection import GroupShuffleSplit

VEHICLE_TYPES = ("Aircraft", "Cargo", "Tanker", "Bus", "Tug", "FollowMe")
FEATURES = tuple(
    f"{kind}.{stat}" for kind in VEHICLE_TYPES
    for stat in ("count", "mean_speed", "mean_turn_speed", "clearance_fraction")
)


def read_csv(path, required):
    with path.open(encoding="utf-8-sig", newline="") as file:
        reader = csv.DictReader(file)
        missing_columns = set(required) - set(reader.fieldnames or ())
        if missing_columns:
            raise ValueError(f"{path.name}: missing columns {sorted(missing_columns)}")
        rows = []
        for row in reader:
            if None in row or any(row[column] is None for column in required):
                raise ValueError(f"{path.name}:{reader.line_num}: malformed CSV row")
            rows.append(row)
        return rows


def nonnegative(value, field, scenario):
    try:
        number = float(value)
    except (ValueError, TypeError):
        raise ValueError(f"{scenario}: invalid {field} {value!r}") from None
    if not math.isfinite(number) or number < 0:
        raise ValueError(f"{scenario}: invalid {field} {value!r}")
    return number


def load_scenarios(folder, zones):
    config_columns = (
        "scenario", "episodeSeed", "vehicleId", "vehicleType",
        "hasClearance", "speed", "turnSpeed",
    )
    scenarios = {}
    for config in sorted(folder.glob("Scenario_*_config.csv")):
        scenario = config.stem.removesuffix("_config")
        vehicles = defaultdict(list)
        seeds = set()
        vehicle_ids = set()
        for row in read_csv(config, config_columns):
            kind = row["vehicleType"]
            vehicle_id = row["vehicleId"]
            if row["scenario"] != scenario or kind not in VEHICLE_TYPES:
                raise ValueError(f"{scenario}: invalid scenario or vehicle type {kind!r}")
            if not vehicle_id or vehicle_id in vehicle_ids:
                raise ValueError(f"{scenario}: empty or duplicate vehicle ID {vehicle_id!r}")
            vehicle_ids.add(vehicle_id)
            seeds.add(int(row["episodeSeed"]))
            if row["hasClearance"] not in {"0", "1"}:
                raise ValueError(f"{scenario}: hasClearance must be 0 or 1")
            vehicles[kind].append((
                nonnegative(row["speed"], "speed", scenario),
                nonnegative(row["turnSpeed"], "turnSpeed", scenario),
                int(row["hasClearance"]),
            ))
        if len(seeds) != 1:
            raise ValueError(f"{scenario}: expected one seed and at least one vehicle")
        event_file = folder / f"{scenario}_events.csv"
        events = Counter()
        for row in read_csv(event_file, ("zoneType", "eventType")):
            zone = row["zoneType"].strip()
            event = row["eventType"].strip().casefold()
            if zone not in zones or event not in {"conflict", "incursion"}:
                raise ValueError(f"{scenario}: unrecognized event row ({zone!r}, {event!r})")
            if event == "incursion" and zone != "Runway":
                raise ValueError(f"{scenario}: incursion outside the Runway category")
            events[zone, event] += 1
        scenarios[scenario] = (seeds.pop(), vehicles, events)
    if not scenarios:
        raise ValueError(f"No Scenario_*_config.csv files in {folder}")
    return scenarios


def scenario_features(vehicles, capped_kind=None, cap=None):
    features = []
    for kind in VEHICLE_TYPES:
        rows = vehicles.get(kind, ())
        if not rows:
            features.extend((0, 0, 0, 0))
            continue
        speeds, turns, clearances = zip(*rows)
        if kind == capped_kind:
            speeds = tuple(min(speed, cap) for speed in speeds)
        count = len(rows)
        features.extend((count, sum(speeds) / count, sum(turns) / count, sum(clearances) / count))
    return features


def dataset(scenarios, ids, zones, level):
    features, conflicts, incursions = [], [], []
    units = (None,) if level == "episode" else zones
    for scenario_id in ids:
        _, vehicles, events = scenarios[scenario_id]
        initial = scenario_features(vehicles)
        for unit in units:
            event_zones = zones if unit is None else (unit,)
            row = initial if unit is None else initial + [int(unit == z) for z in zones]
            features.append(row)
            conflicts.append(int(any(events[z, "conflict"] for z in event_zones)))
            incursions.append(sum(events[z, "incursion"] for z in event_zones))
    return np.asarray(features), np.asarray(conflicts), np.asarray(incursions)


def fit_agent_a(scenarios, train_ids, test_ids, zones, seed):
    models, metrics = {}, {}
    for level in ("episode", "zone_type"):
        train_x, train_conflict, train_incursions = dataset(scenarios, train_ids, zones, level)
        test_x, test_conflict, test_incursions = dataset(scenarios, test_ids, zones, level)
        if np.unique(train_conflict).size < 2:
            raise ValueError(f"{level}: training requires both conflict and no-conflict examples")
        classifier = HistGradientBoostingClassifier(random_state=seed, early_stopping=False)
        regressor = HistGradientBoostingRegressor(random_state=seed, early_stopping=False)
        classifier.fit(train_x, train_conflict)
        regressor.fit(train_x, train_incursions)
        probability = classifier.predict_proba(test_x)[:, 1]
        count_prediction = np.maximum(0, regressor.predict(test_x))
        metrics[level] = {
            "train_rows": len(train_x),
            "test_rows": len(test_x),
            "test_conflict_prevalence": float(test_conflict.mean()),
            "conflict_roc_auc": (
                roc_auc_score(test_conflict, probability) if np.unique(test_conflict).size == 2 else None
            ),
            "conflict_f1_at_0_5": f1_score(test_conflict, probability >= 0.5, zero_division=0),
            "incursion_mae": mean_absolute_error(test_incursions, count_prediction),
            "incursion_r2": (
                r2_score(test_incursions, count_prediction) if np.unique(test_incursions).size > 1 else None
            ),
        }
        models[level] = {"conflict": classifier, "incursion_count": regressor}
    return models, metrics


def fit_agent_b(scenarios, train_ids, zones, zone_models, conflict_limit, incursion_limit):
    """Screen candidate speed caps with Agent A and produce a rule table."""
    rows = []
    for zone_index, zone in enumerate(zones):
        zone_features = [int(index == zone_index) for index in range(len(zones))]
        for kind in VEHICLE_TYPES:
            contexts = [
                scenarios[scenario][1] for scenario in train_ids if kind in scenarios[scenario][1]
            ]
            speeds = [vehicle[0] for context in contexts for vehicle in context[kind]]
            row = {
                "zoneType": zone, "vehicleType": kind, "speedCap": None,
                "accessRecommendation": "review", "status": "insufficient_training_context",
                "meanConflictProbability": None, "meanIncursionCount": None,
                "trainingContexts": len(contexts),
            }
            # Require observed contexts before generating any candidate recommendation.
            if len(contexts) >= 5:
                candidates = sorted(set(np.quantile(speeds, [0.25, 0.5, 0.75, 0.9])), reverse=True)
                row.update(accessRecommendation="hold", status="no_candidate_passed")
                for candidate in candidates:
                    matrix = np.asarray([
                        scenario_features(context, kind, candidate) + zone_features
                        for context in contexts
                    ])
                    risk = float(zone_models["conflict"].predict_proba(matrix)[:, 1].mean())
                    incursions = float(np.maximum(0, zone_models["incursion_count"].predict(matrix)).mean())
                    if risk <= conflict_limit and incursions <= incursion_limit:
                        row.update(
                            speedCap=float(candidate), accessRecommendation="eligible_if_already_authorized",
                            status="candidate_passed", meanConflictProbability=risk,
                            meanIncursionCount=incursions,
                        )
                        break
            rows.append(row)
    return rows


def train(args):
    zones = tuple(args.zones)
    if len(set(zones)) != len(zones):
        raise ValueError("Zone types must be unique")
    if not (0 <= args.conflict_limit <= 1 and math.isfinite(args.incursion_limit)
            and args.incursion_limit >= 0):
        raise ValueError("Conflict limit must be in [0, 1]; incursion limit must be finite and nonnegative")
    scenarios = load_scenarios(args.data, zones)
    ids = np.asarray(list(scenarios))
    seeds = np.asarray([scenarios[scenario][0] for scenario in ids])
    if len(set(seeds)) < 5:
        raise ValueError("At least five distinct scenario seeds are required for a held-out split")
    if len(set(seeds)) != len(seeds):
        raise ValueError("Repeated seeds found. Supply one baseline export per scenario seed")
    splitter = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=args.seed)
    train_indices, test_indices = next(splitter.split(ids, groups=seeds))
    train_ids, test_ids = ids[train_indices].tolist(), ids[test_indices].tolist()
    models, metrics = fit_agent_a(scenarios, train_ids, test_ids, zones, args.seed)
    policy = fit_agent_b(
        scenarios, train_ids, zones, models["zone_type"], args.conflict_limit, args.incursion_limit
    )
    args.out.mkdir(parents=True, exist_ok=False)
    metadata = {
        "implementation": "reference reconstruction",
        "sklearn_version": sklearn.__version__,
        "random_seed": args.seed,
        "zone_types": zones,
        "features": FEATURES,
        "zone_type_features": FEATURES + tuple(f"zone_type.{z}" for z in zones),
        "train_scenarios": train_ids,
        "test_scenarios": test_ids,
        "agent_a_held_out_metrics": metrics,
        "agent_b_screening": {
            "conflict_probability_limit": args.conflict_limit,
            "incursion_count_limit": args.incursion_limit,
            "candidate_caps_passing": sum(row["status"] == "candidate_passed" for row in policy),
        },
    }
    joblib.dump({"models": models, "metadata": metadata}, args.out / "agent_a.joblib")
    (args.out / "run_report.json").write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    with (args.out / "agent_b_simulation_candidates.csv").open("w", encoding="utf-8", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(policy[0]))
        writer.writeheader()
        writer.writerows(policy)
    print(f"Reference training finished. Output: {args.out}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--data", type=Path, required=True, help="Folder with verified baseline exports")
    parser.add_argument("--out", type=Path, required=True, help="New output folder")
    parser.add_argument("--zones", nargs="+", required=True, help="Verified fixed zone-type inventory")
    parser.add_argument("--conflict-limit", type=float, required=True)
    parser.add_argument("--incursion-limit", type=float, required=True)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    try:
        train(args)
    except (ValueError, OSError) as error:
        parser.exit(2, f"Error: {error}\n")


if __name__ == "__main__":
    main()
