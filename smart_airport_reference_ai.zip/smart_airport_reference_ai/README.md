# Smart Airport Agent A and Agent B reference implementation

This package is a post-study reconstruction based on the documented methods. The original experiment used a separate implementation. The code here has not been verified to reproduce the paper’s reported metrics, deployed policy table or simulation results.

## Run the training

Use Python 3.12 and a fresh environment. From this folder:

```text
python -m pip install -r requirements.txt
python train_agents.py --data path/to/verified_baseline_exports --out runs/reference-01 --zones Runway Apron Intersection ServiceRoad --conflict-limit 0.40 --incursion-limit 1.0
```

Use the zone categories confirmed for your exports. The limits in this example illustrate the command. The conflict limit applies to mean predicted conflict probability. The incursion limit applies to mean predicted incursion count per scenario and zone type. Choose and document these limits before evaluating any resulting policy.

## Input files

For each baseline seed, place the matching files in one directory:

| File | Required columns |
| --- | --- |
| `Scenario_001_config.csv` | `scenario,episodeSeed,vehicleId,vehicleType,hasClearance,speed,turnSpeed` |
| `Scenario_001_events.csv` | `zoneType,eventType` |

Supported vehicle categories are `Aircraft`, `Cargo`, `Tanker`, `Bus`, `Tug`, and `FollowMe`. An event file for a scenario with zero events must still exist and contain the header. Events must use `Conflict` or `Incursion`. Use independently verified event exports with one row per incursion. Unverified or corrupted logs should be excluded. Scenario configurations alone contain no outcome labels. Aggregate KPI totals alone cannot supply the zone-type labels required by this implementation.

The zone inventory is assumed to be shared by all supplied scenarios. Zone-level modeling here groups events by zone **type** across the scenario. It does not estimate risk for each individual road segment or zone identifier. Added or renamed categories require a consistent schema mapping.

## What each agent does

- **Agent A** fits histogram gradient boosting classifiers for conflict occurrence and regressors for incursion counts at episode and zone-type levels. It splits by scenario seed before fitting, keeping a scenario and all of its zone rows in the same partition. Initial configuration values and the declared zone type form the features. Event data are used only as labels. This version omits optional historical event features and disables early stopping so that no internal row-level validation split can mix zones from the same scenario.
- **Agent B** synthesizes a decision table. It takes candidate speed caps from training-set speed quantiles, clips the selected vehicle class’s starting speeds in the feature calculation, and uses Agent A to screen them against the two limits. It chooses the highest screened cap that passes, averaged over the training contexts. This is model-based screening, so the output is a candidate policy rather than a measured treatment effect. Classes with too little support are flagged for review. An eligible access recommendation is conditional on existing authorization. The script implements no Unity enforcement or new clearance grant.

## Outputs

- `agent_a.joblib` contains fitted models and their feature order.
- `run_report.json` records the scenario split, held-out Agent A metrics, and the Agent B screening settings. A null ROC-AUC or R² indicates insufficient variation in the held-out target for that metric.
- `agent_b_simulation_candidates.csv` contains speed-cap candidates and access recommendations by zone and vehicle type. A blank cap means no candidate is available. The table is for offline simulation review and requires an explicit integration step before it can be used by Unity.

Only load model files from trusted sources. A paired simulation run would be needed to evaluate the exported candidate policy. This package does not generate or verify the paper’s original effect sizes.

## Suggested repository or paper disclosure

> The repository includes a reference implementation of Agent A training and Agent B policy synthesis reconstructed from the documented methods after the study. The original training and policy-generation scripts are unavailable. The reference implementation has not been verified to reproduce the reported numerical results.
